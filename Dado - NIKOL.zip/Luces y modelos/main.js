import * as THREE from './node_modules/three/build/three.module.js';
import { OrbitControls } from './node_modules/three/examples/jsm/controls/OrbitControls.js';
import { OBJLoader } from './node_modules/three/examples/jsm/loaders/OBJLoader.js';
import { MTLLoader } from './node_modules/three/examples/jsm/loaders/MTLLoader.js';

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x808080);
scene.fog = new THREE.Fog(0x808080, 10, 50);

const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
camera.position.set(-15, 9, 0);

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = 0.05;
controls.screenSpacePanning = false;
controls.maxPolarAngle = Math.PI / 2;

scene.add(new THREE.AmbientLight(0xffffff, 0.8));
const directionalLight = new THREE.DirectionalLight(0xffffff, 3);
directionalLight.position.set(10, 15, 10);
scene.add(directionalLight);

const textureLoader = new THREE.TextureLoader();
const mtlLoader = new MTLLoader();
const objLoader = new OBJLoader();

const modelPath = 'src/3d model/Player/';
const scenePath = 'src/3d model/scene/';
const collectiblePath = 'src/3d model/Collectible/';
const Dadopath = 'src/3d model/Dado/';

const hulkTexture = textureLoader.load(modelPath + 'Hulk.png');
hulkTexture.wrapS = THREE.RepeatWrapping;
hulkTexture.wrapT = THREE.RepeatWrapping;

mtlLoader.load(modelPath + 'Hulk.mtl', (materials) => {
    materials.preload();

    Object.values(materials.materials).forEach(material => {
        material.map = hulkTexture;
        material.needsUpdate = true;
    });

    objLoader.setMaterials(materials);
    objLoader.load(modelPath + 'Hulk.obj', (object) => {
        object.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: hulkTexture
                });
            }
        });

        object.position.set(6.8, -1, 4);
        object.scale.set(2, 2, 2);
        object.rotation.y = 3 * Math.PI / 2;
        scene.add(object);
    });
});

const cityTexture = textureLoader.load(scenePath + 'NewYork.png');
mtlLoader.load(scenePath + 'NewYork.mtl', (materials) => {
    materials.preload();
    Object.values(materials.materials).forEach(material => {
        material.map = cityTexture;
        material.needsUpdate = true;
    });

    objLoader.setMaterials(materials);
    objLoader.load(scenePath + 'NewYork.obj', (object) => {
        object.position.set(0, -2, 0);
        object.scale.set(2, 2, 2);
        scene.add(object);
    });
});

const collectibles = [
    { name: "Cabina", obj: "Cabina de telefono.obj", mtl: "Cabina de telefono.mtl", texture: "Cabina de telefono.png" },
    { name: "Puño", obj: "Puño de hulk.obj", mtl: "Puño de hulk.mtl", texture: "Puño de hulk.png" },
    { name: "Roca", obj: "Roca.obj", mtl: "Roca.mtl", texture: "Roca.png" }
];

const collectibleObjects = {};

const collectiblePositions = [
    new THREE.Vector3(-10, 7, 0),
    new THREE.Vector3(-6, 7, 0),
    new THREE.Vector3(-2, 7, 0),
    new THREE.Vector3(2, 7, 0),
    new THREE.Vector3(6, 7, 0),
    new THREE.Vector3(10, 7, 0),
];

collectibles.forEach(item => {
    const texture = textureLoader.load(collectiblePath + item.texture);

    mtlLoader.load(collectiblePath + item.mtl, (materials) => {
        materials.preload();
        Object.values(materials.materials).forEach(material => {
            material.map = texture;
            material.needsUpdate = true;
        });

        objLoader.setMaterials(materials);
        objLoader.load(collectiblePath + item.obj, (object) => {
            object.position.set(0, -5, 0);
            object.scale.set(1, 1, 1);
            object.visible = false;
            scene.add(object);
            collectibleObjects[item.name] = object;
        });
    });
});

let dadoObject = null;
const dadoGroup = new THREE.Group();
scene.add(dadoGroup);

const dadoTexture = textureLoader.load(Dadopath + 'Dado.png');

mtlLoader.load(Dadopath + 'Dado.mtl', (materials) => {
    materials.preload();
    Object.values(materials.materials).forEach(material => {
        material.map = dadoTexture;
        material.needsUpdate = true;
    });

    objLoader.setMaterials(materials);
    objLoader.load(Dadopath + 'Dado.obj', (object) => {
        object.scale.set(5, 5, 5);

        const box = new THREE.Box3().setFromObject(object);
        const center = box.getCenter(new THREE.Vector3());
        object.position.sub(center);

        dadoGroup.add(object);
        dadoGroup.position.set(-9, 0, -1); 
        dadoObject = dadoGroup;
    });
});

let girarDado = false;
let targetRotation = new THREE.Euler();
let rotacionActual = new THREE.Euler();

const dadoRotaciones = {
    6: new THREE.Euler(0, 0, 0),                      
    3: new THREE.Euler(Math.PI / 2, 0, 0),            
    5: new THREE.Euler(0, 0, -Math.PI / 2),           
    2: new THREE.Euler(0, 0, Math.PI / 2),            
    4: new THREE.Euler(-Math.PI / 2, 0, 0),           
    1: new THREE.Euler(Math.PI, 0, 0),                
};

function animate() {
    requestAnimationFrame(animate);
    controls.update();

    if (dadoObject && girarDado) {
        dadoObject.rotation.x += (targetRotation.x - dadoObject.rotation.x) * 0.1;
        dadoObject.rotation.y += (targetRotation.y - dadoObject.rotation.y) * 0.1;
        dadoObject.rotation.z += (targetRotation.z - dadoObject.rotation.z) * 0.1;

        // Detener rotación cuando esté cerca de la rotación objetivo
        const dist = Math.abs(dadoObject.rotation.x - targetRotation.x) +
                     Math.abs(dadoObject.rotation.y - targetRotation.y) +
                     Math.abs(dadoObject.rotation.z - targetRotation.z);

        if (dist < 0.01) {
            girarDado = false;
            dadoObject.rotation.copy(targetRotation); // Asegura que quede exacto
        }
    }

    renderer.render(scene, camera);
}
animate();

let coleccionablesActivos = [];

document.getElementById('rollButton').addEventListener('click', () => {
    // Resultado entre 1 y 6
    const numero = Math.floor(Math.random() * 6) + 1;
    document.getElementById('resultadoDado').textContent = `Resultado: ${numero}`;

    // Aplica rotación correcta para mostrar ese número arriba
    targetRotation = dadoRotaciones[numero].clone();
    girarDado = true;

    // Eliminar coleccionables anteriores
    coleccionablesActivos.forEach(obj => {
        if (obj.parent) obj.parent.remove(obj);
    });
    coleccionablesActivos = [];

    const keys = Object.keys(collectibleObjects);

    for (let i = 0; i < numero; i++) {
        const randomIndex = Math.floor(Math.random() * keys.length);
        const nombre = keys[randomIndex];
        const original = collectibleObjects[nombre];

        const collectible = original.clone();
        collectible.position.copy(collectiblePositions[i]);
        collectible.visible = true;

        scene.add(collectible);
        coleccionablesActivos.push(collectible);
    }

    setTimeout(() => {
        document.getElementById('resultadoDado').textContent = "Resultado: ?";

        coleccionablesActivos.forEach(obj => {
            if (obj.parent) obj.parent.remove(obj);
        });
        coleccionablesActivos = [];
    }, 10000);
});

window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
});